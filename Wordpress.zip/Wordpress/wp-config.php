<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'dbvuqk3as3y5wr' );

/** MySQL database username */
define( 'DB_USER', 'ue9pufbnzwkqy' );

/** MySQL database password */
define( 'DB_PASSWORD', 'b3s7vebj38pa' );

/** MySQL hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'hD#/6?86m:mrlzc@rPbpa2Xf#T);i/p/7M-`9Q#_g1I3f%Dv%tu0X :]lvw?f*X)' );
define( 'SECURE_AUTH_KEY',   '7sWZ<:u.]?*{P#V;$L4M@tswq+0A8|nr!- #JY4`zm]VW}(jm1AVgn &`vj+O sX' );
define( 'LOGGED_IN_KEY',     'P&D):Lm`5.Gu)_X&6Gg0&;i1q#,t!G?+a8`p@CD[36g88BHmcrO>G8G}I?E=U(0)' );
define( 'NONCE_KEY',         'jdj<!deUJLDLxw1LN=H%;%stl( 2s.;D<1Vh?9nRh_Gd~Cgd=G?|[[w!I0ooc/Gl' );
define( 'AUTH_SALT',         'J!e526~v9gbhWJnykeAH^?gE:j2Ci~sgqD_W<!<~,1uH4gG;MwlX]UHO@4l$4Z!|' );
define( 'SECURE_AUTH_SALT',  'nrls}ro3O.:[x3sct;F|@.M2:9DZWG[E2gM|a3<Su6#I9iIp6{o_87{@@]qp~PH^' );
define( 'LOGGED_IN_SALT',    'WNsa 7#ZAq].Lt~4O3vUW1*|JAMP-jZ /Qb3p1jXW7?CO/<Rn1qHx%CW$6}Tmfr9' );
define( 'NONCE_SALT',        'j:KMtfGAy:mhZ~oSWTG)ov{)iWJ;l^ep<[-cdx:(.[I{{B<jRIq>kReB|cd!Rgw-' );
define( 'WP_CACHE_KEY_SALT', 'z]1+#=4 `ZZm=odHXsP7~qZ+%J__Scopj,,0L<+P98wZ=nFe>&cFr<7{|mDflx*A' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'vtk_';






define( 'WP_ALLOW_MULTISITE', true );
define( 'MULTISITE', true );
define( 'SUBDOMAIN_INSTALL', false );
define( 'DOMAIN_CURRENT_SITE', 'juliane.sgedu.site' );
define('PATH_CURRENT_SITE', '/Wordpress/');
define( 'SITE_ID_CURRENT_SITE', 1 );
define( 'BLOG_ID_CURRENT_SITE', 1 );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
@include_once('/var/lib/sec/wp-settings.php'); // Added by SiteGround WordPress management system
